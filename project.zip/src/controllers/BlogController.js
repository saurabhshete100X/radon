const BlogModel = require("../models/blogModel")
const authorModel = require("../models/authorModel");
const blogModel = require("../models/blogModel");
const createBlog = async function(req, res) {
    try {
        const details = req.body;
        if (!details.title) return res.status(400).send({ status: false, msg: "Title of the blog is required" });
        if (!details.body) return res.status(400).send({ status: false, msg: "Body of the blog is required" });
        if (!details.authorId) return res.status(400).send({ status: false, msg: "Author_Id of the blog is required" });
        if (!details.category) return res.status(400).send({ status: false, msg: "Category of the blog is required" });
        const validate = await authorModel.findById(details.authorId)
        if (!validate) return res.status(400).send({ status: false, msg: "Please enter valid authorId" })
        const data = await BlogModel.create(details)
        res.status(201).send({ status: true, msg: data })
    } catch (err) {
        res.status(400).send({ status: false, Error: err.message })
    }
}
const getBlog = async function(req, res) {
    try {
        let authorId = req.query.authorId
        let valid = await authorModel.findById(authorId)
        if (!valid) return res.status(404).send({ status: false, msg: "enter valid authorID" })
        let tags = req.query.tags
        let category = req.query.category
        let getData = await BlogModel.findOne({ authorId: valid, tags: tags, category: category, isDeleted: false, isPublished: true })
        if (!getData) return res.status(404).send({ status: false, msg: "Please enter valid information" })
        console.log(getData)
        res.status(201).send({ status: true, data: getData })
    } catch (err) {
        res.status(404).send({ status: false, Error: err.message })
    }
}
const updateBlog = async function(req, res) {
    try {
        let data = req.body
        let blog_Id = req.params.blogId
        if (data.subcategory) {
            let subcategory = data.subcategory.split(",").map((x) => (x.trim()))
            data.subcategory = subcategory
        }
        if (data.tags) {
            let tags = data.tags.split(",").map((x) => (x.trim()))
            data.tags = tags
        }
        let checkBlog = await blogModel.findById(blog_Id)
        if (!checkBlog) return res.status(404).send({ status: false, msg: "Blog Not Found" })
        if (checkBlog.isDeleted == true) return res.status(400).send({ status: false, msg: "This blog is already Deleted" })
        let update = await blogModel.findByIdAndUpdate(blog_Id, { $push: { tags: data.tags, subcategory: data.subcategory }, title: data.title, body: data.body, isPublished: true, publishedAt: new Date() }, { new: true })
        res.status(200).send({ status: true, data: update })
    } catch (err) {
        res.status(500).send({ error: err.message })
    }
}
const deleteBlog =
    module.exports = { createBlog, getBlog, updateBlog }